#include <iostream>
#include "depreciation.h"

using namespace std;

double Depreciation::getPercent()const
    {
        return percent;
    }
double Depreciation::getCapital()const
    {
        return capital;
    }
double Depreciation::getMonth()const
    {
        return month;
    }
double Depreciation::getDepreciationGoodValue ()const
    {
        //check whether the value less than zero;
        for (int i = 0; i < month; i++)
        {
            double totalDep;
            totalDep = capital *(1-i*percent/100);

            //if value less than equal to zero, exception will be thrown
            if (totalDep <= 0)
            {
                throw i;
            }
        }

        return capital *(1-month*percent/100);
    }
double Depreciation::getDepreciationBookValue ()const
    {
        for (int i = 0; i < month; i++)
        {
            double totalDep;
            totalDep = percent/100*capital*pow((1-percent/100),month-1);

            //if value less than equal to zero, exception will be thrown
            if (totalDep <= 0)
            {
                throw i;
            }
        }
        return percent/100*capital*pow((1-percent/100),month-1);
    }

